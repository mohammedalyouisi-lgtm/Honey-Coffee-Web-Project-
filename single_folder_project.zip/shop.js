/* ===== shop.js — فلترة المنتجات + سلة محلية ===== */
(function(){
  const CART_KEY = 'cart_items_v1';
  const load = ()=>{ try { return JSON.parse(localStorage.getItem(CART_KEY)||'[]'); } catch(e){ return []; } };
  const save = (arr)=> localStorage.setItem(CART_KEY, JSON.stringify(arr));
  const currency = (n)=> (Number(n)||0).toFixed(2) + '$';

  function ensureFilterUI(productsContainer){
    if(!productsContainer) return;
    if(document.getElementById('filter-box')) return;

    const box = document.createElement('fieldset');
    box.id = 'filter-box';
    box.innerHTML = `
      <legend>تصفية</legend>
      <label><input type="radio" name="ftype" id="f-all" checked> الكل</label>
      <label><input type="radio" name="ftype" id="f-honey"> عسل</label>
      <label><input type="radio" name="ftype" id="f-coffee"> قهوة</label>
    `;
    productsContainer.parentNode.insertBefore(box, productsContainer);
  }

  function categorizeCards(productsContainer){
    const cards = productsContainer ? productsContainer.querySelectorAll('.card, article, .product') : [];
    let idx = 0;
    cards.forEach(card=>{
      idx += 1;
      const text = (card.textContent||'').toLowerCase();
      let t = 'other';
      if(text.includes('عسل') || text.includes('honey')) t = 'honey';
      if(text.includes('قهوة') || text.includes('بن') || text.includes('coffee')) t = 'coffee';
      if(!card.dataset.id) card.dataset.id = 'p'+idx;
      if(!card.dataset.name){
        const h = card.querySelector('h3, h2, .title');
        card.dataset.name = h ? (h.textContent||('منتج '+idx)) : ('منتج '+idx);
      }
      if(!card.dataset.price){
        const price = (card.textContent.match(/(\d+(\.\d+)?)\s*(\$|ر\.س|sar)/i)||[])[1] || '10';
        card.dataset.price = price;
      }
      card.dataset.type = card.dataset.type || t;

      // زر add-to-cart
      if(!card.querySelector('.add-to-cart')){
        const btn = document.createElement('button');
        btn.className = 'btn add-to-cart';
        btn.textContent = 'أضف للسلة';
        btn.setAttribute('type','button');
        card.appendChild(btn);
      }
    });
  }

  function wireFilters(productsContainer){
    const items = productsContainer ? Array.from(productsContainer.querySelectorAll('[data-type]')) : [];
    const show = (t)=>{
      items.forEach(it=>{
        it.style.display = (!t || it.dataset.type===t) ? '' : 'none';
      });
    };
    const fh = document.getElementById('f-honey');
    const fc = document.getElementById('f-coffee');
    const fa = document.getElementById('f-all');
    fa && fa.addEventListener('change', ()=>show(null));
    fh && fh.addEventListener('change', ()=>show('honey'));
    fc && fc.addEventListener('change', ()=>show('coffee'));
    show(null);
  }

  function wireCartButtons(root){
    root.addEventListener('click', (e)=>{
      const btn = e.target.closest('.add-to-cart');
      if(!btn) return;
      // Find nearest card
      const card = btn.closest('[data-id]') || btn.closest('.card, article, .product');
      if(!card) return;
      const id = card.dataset.id || btn.dataset.id;
      const name = card.dataset.name || btn.dataset.name || 'منتج';
      const price = parseFloat(card.dataset.price || btn.dataset.price || '10');
      const cart = load();
      const found = cart.find(i=>i.id===id);
      if(found){ found.qty += 1; } else { cart.push({id, name, price, qty: 1}); }
      save(cart);
      try { btn.textContent = '✓ تمت الإضافة'; setTimeout(()=>btn.textContent='أضف للسلة', 1200); } catch(e){}
    });
  }

  function renderCartIfExists(){
    const cartRoot = document.getElementById('cart-root');
    const cartList = document.getElementById('cart-list');
    if(!cartRoot && !cartList) return;

    // Ensure table structure if only cart-root exists
    if(cartRoot && !cartList){
      cartRoot.innerHTML = `
        <table class="table">
          <thead><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th><th></th></tr></thead>
          <tbody id="cart-list"></tbody>
          <tfoot><tr><td colspan="3">الإجمالي</td><td id="cart-total">0$</td><td></td></tr></tfoot>
        </table>
      `;
    }
    const list = document.getElementById('cart-list');
    const totalEl = document.getElementById('cart-total');
    if(!list || !totalEl) return;

    const cart = load();
    let total = 0;
    list.innerHTML = cart.map(i=>{
      const line = i.price * i.qty; total += line;
      return `<tr><td>${i.name}</td><td>${i.qty}</td><td>${currency(i.price)}</td><td>${currency(line)}</td>
        <td><button class="btn remove" data-id="${i.id}">حذف</button></td></tr>`;
    }).join('') || `<tr><td colspan="5">السلة فارغة</td></tr>`;
    totalEl.textContent = currency(total);

    // Remove handlers
    list.addEventListener('click', (e)=>{
      const btn = e.target.closest('.remove');
      if(!btn) return;
      const id = btn.getAttribute('data-id');
      let cart = load().filter(i=>i.id!==id);
      save(cart);
      renderCartIfExists();
    });
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    const productsContainer = document.querySelector('.products, .product-grid, .items');
    ensureFilterUI(productsContainer);
    categorizeCards(productsContainer);
    wireFilters(productsContainer);
    wireCartButtons(document);
    renderCartIfExists();
  });
})();