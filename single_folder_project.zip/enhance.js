/* ===== Enhance.js — وظائف عامة بدون كسر منطق الموقع ===== */
(function(){
  // Theme: حفظ/استرجاع النمط (فاتح/داكن)
  const saved = localStorage.getItem('theme');
  if(saved){ document.documentElement.setAttribute('data-theme', saved); }
  const btn = document.getElementById('theme-toggle');
  if(btn){
    btn.addEventListener('click', ()=>{
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const next = isDark ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
    });
  }

  // Validation: تحقق مبسّط لأي form عليه data-validate
  document.querySelectorAll('form[data-validate]').forEach(form=>{
    form.addEventListener('submit', (e)=>{
      let ok = true;
      // الحقول المطلوبة: [required]
      form.querySelectorAll('[required]').forEach(el=>{
        const val = (el.value || '').trim();
        if(!val){ ok = false; el.setAttribute('aria-invalid','true'); }
        else { el.removeAttribute('aria-invalid'); }
      });
      // بريد إلكتروني (اختياري) إذا وُجد input[type=email]
      const email = form.querySelector('input[type="email"]');
      if(email && email.value){
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!re.test(email.value.trim())){ ok=false; email.setAttribute('aria-invalid','true'); }
      }
      // رسالة حالة
      let out = form.querySelector('.form-output');
      if(!out){
        out = document.createElement('div');
        out.className = 'form-output';
        form.appendChild(out);
      }
      if(!ok){
        e.preventDefault();
        out.textContent = 'يرجى إكمال الحقول المطلوبة والتأكد من البريد الإلكتروني.';
        out.style.color = '#dc2626';
      }else{
        out.textContent = 'تم التحقق من البيانات (محلياً).';
        out.style.color = '#16a34a';
      }
    });
  });

  // أزرار إظهار/إخفاء باستخدام data-toggle="#target"
  document.querySelectorAll('[data-toggle]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const sel = btn.getAttribute('data-toggle');
      if(!sel) return;
      const target = document.querySelector(sel);
      if(target){ target.hidden = !target.hidden; }
    });
  });
})();